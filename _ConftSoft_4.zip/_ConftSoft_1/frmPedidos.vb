﻿Public Class frmPedidos

    Private Sub btnEnviar_Click(sender As Object, e As EventArgs) Handles btnEnviar.Click
        Try
            If txtCel.Text = "" Or txtCliente.Text = "" Or txtDataPedido.Text = "" Or txtObs.Text = "" Or txtPedido.Text = "" Then
                MsgBox("Preencha todos os campos", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Else
                sql = "insert into tb_cliente (celularCliente, nomeCliente) values ('" & txtCel.Text & "', '" & txtCliente.Text & "')"
                sql2 = "insert into tb_pedidos (tipoPedido, dataPedido, obsPedido) values ('" & txtPedido.Text & "', '" & txtDataPedido.Text & "', '" & txtObs.Text & "')"
                rs = db.Execute(sql)
                rs = db.Execute(sql2)
                MsgBox("Pedido realizado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            End If
        Catch ex As Exception
            MsgBox("Verifique os campos ", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Private Sub frmPedidos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_bd()
    End Sub


End Class