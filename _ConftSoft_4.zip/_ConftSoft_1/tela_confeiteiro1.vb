﻿Public Class tela_confeiteiro1
    Private Sub tela_confeiteiro1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_bd()
        sql = "select * from tb_pedidos order by obsPedido asc"
        rs = db.Execute(sql)
        TextBox1.Text = rs.Fields(3).Value
        lblNumeroPedido.Text = rs.Fields(0).Value

    End Sub


End Class