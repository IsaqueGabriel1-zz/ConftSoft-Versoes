﻿Public Class Form1
    Private Sub btnLogar_Click(sender As Object, e As EventArgs) Handles btnLogar.Click
        Try
            If txtNome.Text = "" And txtSenha.Text = "" Then
                MsgBox("Preencha todos os campos", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Else
                sql = "select * from tb_cadastro where nomeUser = '" & txtNome.Text & "' AND senha = '" & txtSenha.Text & "'"
                rs = db.Execute(sql)
                nivel = rs.Fields(3).Value
                If rs.EOF = False Then
                    If nivel = 1 Then
                        'MsgBox("balconista")
                        frmPedidos.Show()
                    Else
                        If nivel = 5 Then
                            'MsgBox("Cozinheiro")
                            frmTelaChefeCozinha.Show()
                        ElseIf nivel = 10 Then
                            'MsgBox("Adm")
                            frmGerencia.Show()
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            txtNome.Text = ""
            txtSenha.Text = ""
            lblErroSenha.Visible = True
            'MsgBox("Uma erro foi encontrado na execução do sistema")
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_bd()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        NovaSenha.Show()
    End Sub

    Private Sub txtNome_MouseClick(sender As Object, e As MouseEventArgs) Handles txtNome.MouseClick
        lblErroSenha.Visible = False
    End Sub
End Class