﻿Module Modulo
    Public db As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public diretorio, sql, sql2, cont As String
    Public banco = Application.StartupPath & "\banco_dados\BancoCS.mdb"
    Public resp As String
    Public nivel As Integer
    Sub conecta_bd()
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("Provider=Microsoft.JET.OLEDB.4.0;Data Source=" & banco)
            MsgBox("Conexao com o banco de dados Ok", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao conectar ao banco", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
            MsgBox(banco)
        End Try
    End Sub

    Sub carregar_dados()
        sql = "select * from tb_estoque order by codProduto asc"
        rs = db.Execute(sql)
        With frmGerencia.dgv_dados
            cont = 0
            .Rows.Clear()
            Do While rs.EOF = False
                .Rows.Add(rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, Nothing, Nothing)
                cont = cont + 1
                rs.MoveNext()
            Loop
        End With
    End Sub
End Module
