﻿Public Class tela_confeiteiro
    Private Sub tela_confeiteiro_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class