﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class tela_confeiteiro1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(tela_confeiteiro1))
        Me.txt_infomacao = New System.Windows.Forms.Label()
        Me.lblNumeroPedido = New System.Windows.Forms.Label()
        Me.txt_pedido = New System.Windows.Forms.Label()
        Me.btn_Detanhe = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txt_infomacao
        '
        Me.txt_infomacao.AutoSize = True
        Me.txt_infomacao.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(187, Byte), Integer))
        Me.txt_infomacao.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.txt_infomacao.ForeColor = System.Drawing.Color.FromArgb(CType(CType(211, Byte), Integer), CType(CType(104, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txt_infomacao.Location = New System.Drawing.Point(31, 44)
        Me.txt_infomacao.Name = "txt_infomacao"
        Me.txt_infomacao.Size = New System.Drawing.Size(221, 26)
        Me.txt_infomacao.TabIndex = 2
        Me.txt_infomacao.Text = "informaçao do pedido"
        '
        'lblNumeroPedido
        '
        Me.lblNumeroPedido.AutoSize = True
        Me.lblNumeroPedido.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(187, Byte), Integer))
        Me.lblNumeroPedido.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.lblNumeroPedido.ForeColor = System.Drawing.Color.FromArgb(CType(CType(211, Byte), Integer), CType(CType(104, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.lblNumeroPedido.Location = New System.Drawing.Point(315, 44)
        Me.lblNumeroPedido.Name = "lblNumeroPedido"
        Me.lblNumeroPedido.Size = New System.Drawing.Size(37, 26)
        Me.lblNumeroPedido.TabIndex = 3
        Me.lblNumeroPedido.Text = "N°"
        '
        'txt_pedido
        '
        Me.txt_pedido.AutoSize = True
        Me.txt_pedido.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(187, Byte), Integer))
        Me.txt_pedido.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!)
        Me.txt_pedido.ForeColor = System.Drawing.Color.FromArgb(CType(CType(211, Byte), Integer), CType(CType(104, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.txt_pedido.Location = New System.Drawing.Point(153, 115)
        Me.txt_pedido.Name = "txt_pedido"
        Me.txt_pedido.Size = New System.Drawing.Size(80, 26)
        Me.txt_pedido.TabIndex = 4
        Me.txt_pedido.Text = "Pedido"
        '
        'btn_Detanhe
        '
        Me.btn_Detanhe.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(152, Byte), Integer))
        Me.btn_Detanhe.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Detanhe.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Detanhe.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btn_Detanhe.ForeColor = System.Drawing.Color.FromArgb(CType(CType(211, Byte), Integer), CType(CType(104, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.btn_Detanhe.Location = New System.Drawing.Point(77, 447)
        Me.btn_Detanhe.Margin = New System.Windows.Forms.Padding(0)
        Me.btn_Detanhe.Name = "btn_Detanhe"
        Me.btn_Detanhe.Size = New System.Drawing.Size(213, 48)
        Me.btn_Detanhe.TabIndex = 12
        Me.btn_Detanhe.Text = "Detalhes do pedido"
        Me.btn_Detanhe.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(97, 170)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(193, 196)
        Me.TextBox1.TabIndex = 13
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-5, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(405, 503)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'tela_confeiteiro1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(176, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(403, 504)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btn_Detanhe)
        Me.Controls.Add(Me.txt_pedido)
        Me.Controls.Add(Me.lblNumeroPedido)
        Me.Controls.Add(Me.txt_infomacao)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "tela_confeiteiro1"
        Me.Text = "tela_confeiteiro1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_infomacao As Label
    Friend WithEvents lblNumeroPedido As Label
    Friend WithEvents txt_pedido As Label
    Friend WithEvents btn_Detanhe As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
