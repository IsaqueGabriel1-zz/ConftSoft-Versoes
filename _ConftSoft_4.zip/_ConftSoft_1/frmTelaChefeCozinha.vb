﻿Public Class frmTelaChefeCozinha
    Private Sub frmTelaChefeCozinha_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class